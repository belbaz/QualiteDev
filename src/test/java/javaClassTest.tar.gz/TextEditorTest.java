import fr.einfolearning.tp2.metiers.TextEditor;
import fr.einfolearning.tp2.metiers.exceptions.EmacsKillRingOverflowException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class TextEditorTest {

    private TextEditor textEditor;

    @BeforeEach
    void setUp() {
        // Initialisation avant chaque test
        textEditor = new TextEditor("Ceci est un exemple de texte pour textEditor");
    }

    @Test
    void testYankPop() throws EmacsKillRingOverflowException, IllegalAccessException {
        // Arrange
        textEditor.setCursor(5);
        textEditor.setMark(10);
        textEditor.killRingBackup(); // Copie la zone marquée dans le kill ring

        // Act
        textEditor.yankPop();

        // Assert
        assertEquals("Ceci est un exemple de texte pour textEditor", textEditor.getBuffer());
    }

    @Test
    void testYankPopWithoutYank() {
        // Act & Assert
        assertThrows(IllegalAccessException.class, () -> textEditor.yankPop());
    }
}
